public interface Categorizable {
    void displayCategoryDetails();
}
