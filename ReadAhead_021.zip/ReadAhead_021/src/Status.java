public enum Status {

    BORROWED,
    AVAILABLE;

}
